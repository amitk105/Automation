package com.crm.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.ContactsPage;
import com.crm.qa.pages.HomePage;
import com.crm.qa.pages.LoginPage;
import com.crm.qa.util.TestUtil;

public class HomePageTest extends TestBase {
	LoginPage logInPage;
	HomePage homePage;
	ContactsPage contactsPage;
	TestUtil testuti;
	public HomePageTest()
	{
		super();
	}

	@BeforeMethod
	public void setUp() throws InterruptedException
	{
		initialization();
		logInPage = new LoginPage();
		testuti = new TestUtil();
		contactsPage = new ContactsPage();
		homePage =logInPage.Login(prop.getProperty("username"), prop.getProperty("password"));
		
	}
	
	
   @Test(priority=1)
	public void VerifyHomePageTitleTest() throws InterruptedException
	{
	 testuti.waitFor2Sec();
	String	homePageTitle1 = homePage.VerifyHomePageTitle();
	System.out.println(homePageTitle1);
	Assert.assertEquals(homePageTitle1, "CRMPRO","Home Page Title is not matching*****");
	}
	
   @Test(priority=2)
	public void VerifyUSerNameLabelTextTest()
	{
	 testuti.switchToFrame();
	Assert.assertTrue(homePage.VerifyUsernameLabel(),"UserName is incorrect"); 

	}
	
   @Test(priority=3)
   public void RedirectToContactsPageTest()
   {
	   testuti.switchToFrame();
	   contactsPage = homePage.clickOnContactslink();
   }
   
   
	
   @AfterMethod
	public void CloseBrowser()
	{
		driver.quit();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
