
package com.crm.qa.pages;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.openqa.selenium.support.ui.Select;
//import org.testng.Assert;

import com.crm.qa.base.TestBase;

public class LoginPage extends TestBase {
	Actions action = new Actions(driver);
	
	
//	PageFactory : OR
	
	@FindBy(name="username")
	WebElement username;
	
	@FindBy(name="password")
	WebElement password;
	
	@FindBy(xpath="//input[@class='btn btn-small']")
	WebElement loginBtn;

	@FindBy(xpath="/html/body/div[2]/div/a[2]/button")
	WebElement signUpBtn;
	
	@FindBy(xpath="/html/body/div[2]/div/div[1]/a/img")
	WebElement  crmLogo;
	
	@FindBy(xpath="/html/body/div[2]/div/a[1]/small")
	WebElement ForgotPasswordLink;
	
	@FindBy(xpath="//*[@id=\"navbar-collapse\"]/ul/li[1]/a")
    WebElement Featureslink;	
	
	@FindBy(xpath= "//*[@id=\"carousel_intro\"]/button[2]")
	WebElement Imagescroller;
	
	@FindBy(xpath="/html/body/div[2]/div/a[2]/button")
	WebElement SignUpBtn;
	
//    @FindBy(xpath="//*[@id=\"payment_plan_id\"]")
//    WebElement EditionDropDown;
//    Select select = new Select(EditionDropDown);
    
    @FindBy(xpath="//*[@id=\"multipleForm\"]/div[3]/input")
    WebElement FirstName;
    
    @FindBy(xpath="//*[@id=\"multipleForm\"]/div[4]/input")
    WebElement LastName;
    
    @FindBy(xpath="//*[@id=\"multipleForm\"]/div[5]/input")
    WebElement Email;
    
    @FindBy(xpath="//*[@id=\"multipleForm\"]/div[6]/input")
    WebElement ConfirmEmail;
    
    @FindBy(xpath="//*[@id=\"username\"]/input")
    WebElement UserName;

    @FindBy(xpath="//*[@id=\"multipleForm\"]/div[8]/input")
    WebElement Password1;
    
    @FindBy(xpath="//*[@id=\"multipleForm\"]/div[9]/input")
    WebElement ConfirmPassword;
    
    @FindBy(xpath="//*[@id=\"multipleForm\"]/div[11]/div/label/input")
    WebElement RadioBtn;
    
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
		
	}
	
	public String ValidateLoginPageTitle()
	{
		return driver.getTitle();
	}
	
	
	public Boolean ValidateCRMImage()
	{
		return crmLogo.isDisplayed();
	}
	
	public HomePage Login(String un, String pwd) throws InterruptedException
	{
		 username.sendKeys(un);
		 password.sendKeys(pwd);
		 Thread.sleep(2000);
		 action.moveToElement(loginBtn).click().perform();
//	     loginBtn.click();
		 return new HomePage();
				 
	}
	
	public void ClickOnFPlink()
	{
		action.moveToElement(ForgotPasswordLink).click().perform();
	}
	
	
	public String getTextOfFeatureLink()
	{
		String FeatureLinkText=Featureslink.getText();
	     return FeatureLinkText;
	}
	
	public void ScrolltheImage() throws InterruptedException
	{
		for (int i = 0; i < 4; i++) {
         action.moveToElement(Imagescroller).click().perform();
         Thread.sleep(1000);
			
		}
	}
	
//	public void SignUpForm()
//	{
//		action.moveToElement(signUpBtn).click().perform();
//		action.moveToElement(EditionDropDown).click().perform();
//		select.selectByVisibleText("Free Edition");
//		FirstName.sendKeys("Amit");
//		LastName.sendKeys("Kulkarni");
//		Email.sendKeys("kulamit2000@gmail.com");
//		ConfirmEmail.sendKeys("kulamit2000@gmail.com");
//		UserName.sendKeys("kulamit");
//		Password1.sendKeys("amit$8007724842");
//		ConfirmPassword.sendKeys("amit$8007724842");
//	}
	
	
	
	
	
	
	
}