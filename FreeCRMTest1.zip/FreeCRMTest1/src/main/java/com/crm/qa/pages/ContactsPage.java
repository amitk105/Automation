package com.crm.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.crm.qa.base.TestBase;

public class ContactsPage extends TestBase {
	
	@FindBy(xpath="//a[contains(text(),'Contacts')]")
	WebElement Contactslabel;
	
	@FindBy(id="first_name")
	WebElement firstnamefield;
	
	@FindBy(id="surname")
	WebElement surname;

	@FindBy(name="client_lookup")
	WebElement CompanyName;
	
	@FindBy(xpath="//input[@type='submit' and @value='Save']")
	WebElement Save;
	

//	Initializing the Page Objects 
	public ContactsPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public boolean VerifyContactslabel()
	{
		return Contactslabel.isDisplayed();
	}
	
	
	public void SelectContactsByName(String name)
	{
		driver.findElement(By.xpath("//a[text()='"+name+"']//parent::td[@class='datalistrow']"
				+ "//preceding-sibling::td[@class='datalistrow']//input[@name='contact_id']")).click();
	}
	
	public void CreateNewContact(String title, String FN, String LN, String Company)
	{
		Select sel= new Select(driver.findElement(By.xpath("//*[@id=\"contactForm\"]/table/tbody/tr[2]/td[1]/table/tbody/tr[1]/td[2]/select")));
		sel.selectByVisibleText(title);
		firstnamefield.sendKeys(FN);
		surname.sendKeys(LN);
		CompanyName.sendKeys(Company);
		Save.click();
	}
	
	
	
}


 

